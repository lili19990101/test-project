import React from 'react';
import { Route, Switch } from 'react-router-dom';

import ListsView from '../Post/ListsView';
import PostHandleView from '../Post/PostHandleView';

export default () => ((
  <Switch>
    <Route exact path="/" component={ListsView} />
    <Route exact path="/posts" component={ListsView} />
    <Route exact path="/posts/:id" component={PostHandleView} />
  </Switch>
));