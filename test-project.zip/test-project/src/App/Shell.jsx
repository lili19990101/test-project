import React from 'react';

import Routes from './Routes';


export default function Shell() {
  return (
    <div>
      <main className="container">
        <Routes />
      </main>
    </div>
  );
}