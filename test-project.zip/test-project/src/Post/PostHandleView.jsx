import React from 'react';
import { withRouter } from 'react-router-dom';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';

import DetailsCard from '../UI/DetailsCard';
import DisplayField from '../UI/DisplayField';
import Button from '../UI/Button';
import ConfirmModal from '../UI/ConfirmModal';


class PostHandleView extends React.Component {
  constructor() {
    super();
    this.state = {
      isLoading: false,
      isEditing: false,
      isSaving: false,
      showConfirmDeleteModal: false,
      isDeleting: false,
      post: null,
      error: '',
    };

    this.handleEdit = this.handleEdit.bind(this);
    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleDeleteClick = this.handleDeleteClick.bind(this);
    this.handleCancelDelete = this.handleCancelDelete.bind(this);
    this.handleConfirmDelete = this.handleConfirmDelete.bind(this);
  }

  componentDidMount() {
    this.loadPost();
  }

  handleEdit() {
    this.setState({ isEditing: true });
  }

  handleSubmit(event) {
    event.preventDefault();

    this.setState({ isSaving: true });
    const { post } = this.state;
    const onSuccess = (response) => {
      this.post = response.data;
      this.setState({
        isEditing: false,
        isSaving: false,
        post: response.data,
      });
    };

    var mock = new MockAdapter(axios);

    if (this.props.match.params.id === 'create') {
      mock.onPost('/posts/new', post).reply(200);
    } else {
      mock.onPut(`/posts/${post.id}`, post).reply(200);
    }
    this.setState({
      isEditing: false,
      isSaving: false,
    });
  }

  handleCancel() {
    const { id } = this.props.match.params;
    if (id === 'create') {
      this.props.history.push('/posts');
    } else {
      this.setState({
        post: this.post,
        isEditing: false,
      });
    }
  }

  handleInputChange(event) {
    const target = event.target;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    const name = target.name;

    this.setState({
      post: {
        ...this.state.post,
        [name]: value,
      },
    });
  }

  renderForm() {
    const { post, isSaving } = this.state;

    return (
      <DetailsCard>
        <form onSubmit={this.handleSubmit}>
          <div className="form-group">
            <label htmlFor="title">Title</label>
            <input
              type="text"
              className="form-control"
              placeholder="title"
              value={post.title || ''}
              name="title"
              onChange={this.handleInputChange}
              id="title"
            />
          </div>
          <div className="form-group">
            <label htmlFor="digest">Digest</label>
            <input
              type="text"
              className="form-control"
              placeholder="digest"
              value={post.digest || ''}
              name="digest"
              onChange={this.handleInputChange}
              id="digest"
            />
          </div>
          <div className="form-group">
            <label htmlFor="publishedAt">PublishedAt</label>
            <input
              type="text"
              className="form-control"
              placeholder="DD/MM/YYYY"
              value={post.publishedAt || ''}
              name="publishedAt"
              onChange={this.handleInputChange}
              id="publishedAt"
            />
          </div>
          <div className="form-group">
            <label htmlFor="publishedBy">PublishedBy</label>
            <input
              type="text"
              className="form-control"
              placeholder="DD/MM/YYYY"
              value={post.publishedBy || ''}
              name="publishedBy"
              onChange={this.handleInputChange}
              id="publishedBy"
            />
          </div>
          <div className="form-group">
            <label htmlFor="content">Content</label>
            <textarea
              className="form-control"
              placeholder="content"
              value={post.content || ''}
              name="content"
              onChange={this.handleInputChange}
              style={{ height: 80 }}
              id="content"
            />
          </div>
          <Button
            primary
            type="submit"
            className="btn btn-primary"
            disabled={isSaving}
          >
            Save
          </Button>
          <Button
            onClick={this.handleCancel}
            disabled={isSaving}
            style={{ marginLeft: 10 }}
          >
            Cancel
          </Button>
        </form>
      </DetailsCard>
    );
  }

  loadPost() {
    const { id } = this.props.match.params;

    if (id === 'create') {
      this.setState({ post: {}, isEditing: true });
      return;
    }

    this.setState({ isLoading: true, error: '' });
    const onSuccess = (response) => {
      this.post = response.data; //save a copy
      this.setState({
        post: response.data,
        isLoading: false,
      });
    };
    const onFail = (error) => {
      this.setState({
        post: null,
        error: 'Fail',
        isLoading: false,
      });
    };
    axios.get(`/posts/${id}`).then(onSuccess).catch(onFail);
  }

  handleDeleteClick() {
    this.setState({ showConfirmDeleteModal: true });
  }

  handleConfirmDelete() {
    const { post } = this.state;
    this.setState({ isDeleting: true });
    var mock = new MockAdapter(axios);
    mock.onDelete(`/posts/${post.id}`);
    this.props.history.push('/posts');
  }

  handleCancelDelete() {
    this.setState({ showConfirmDeleteModal: false });
  }

  renderDisplay() {
    const { post, isDeleting } = this.state;

    return (
      <DetailsCard>
        <DetailsCard.Header>
          <h1>{post.title}</h1>
        </DetailsCard.Header>
        <DetailsCard.ButtonGroup>
          <Button primary onClick={this.handleEdit}>Edit</Button>
          {post.id > 0 && (
            <Button
              danger
              onClick={this.handleDeleteClick}
              disabled={isDeleting}
              style={{ marginLeft: 10 }}
            >
              {isDeleting ? 'Deleting...' : 'Delete'}
            </Button>
          )}
        </DetailsCard.ButtonGroup>
        <DisplayField label="Digest">{post.digest}</DisplayField>
        <DisplayField label="PublishedAt">{post.publishedAt}</DisplayField>
        <DisplayField label="PublishedBy">{post.publishedBy}</DisplayField>
        <DisplayField label="Content">{post.content}</DisplayField>
        <ConfirmModal
          show={this.state.showConfirmDeleteModal}
          onClose={this.handleCancelDelete}
          onConfirm={this.handleConfirmDelete}
        />
      </DetailsCard>
    );
  }


  render() {
    const { isLoading, error, post, isEditing } = this.state;

    if (isLoading) {
      return (
        <h3>Loading...</h3>
      );
    }
    if (!isLoading && error) {
      return (
        <DetailsCard>{error}</DetailsCard>
      );
    }
    if (post && !isEditing) {
      return this.renderDisplay();
    }

    if (post && isEditing) {
      return this.renderForm();
    }

    return null;
  }
}

export default withRouter(PostHandleView);