import React from 'react';
import { Link } from 'react-router-dom';

export default function PostCard({ post }) {
  return (
    <div className="col-sm-6 col-md-4">
      <div className="my-course-card">      
        <div>{post.title}</div>
        <div>{post.digest}</div>
        <div>{post.publishedAt}</div>
        <br />
        <Link to={`/posts/${post.id}`} className="btn btn-info">
          Details
        </Link>
      </div>
    </div>
  );
}