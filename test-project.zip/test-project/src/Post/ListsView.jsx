import React from 'react';
import axios from 'axios';
import nock from 'nock';
import { Link } from 'react-router-dom';

import PostCard from './PostCard';

import MockAdapter from 'axios-mock-adapter';

var mock = new MockAdapter(axios);

mock.onGet('/posts')
.reply(200, [{
  id: '1',
  title: 'Login code problem',
  digest: 'android development',
  headingImg: 'https://avatars2.githubusercontent.com/u/34058688?v=4',
  publishedAt: '11\/12\/2017',
  publishedBy: 'Tom',
  content: 'Here, I encounter some difficulties including the login activity code'
},{
  id: '2',
  title: 'Android Login/register app',
  digest: ' mini app semblable',
  headingImg: 'https://avatars2.githubusercontent.com/u/35514750?v=4',
  publishedAt: '1\/12\/2018',
  publishedBy: 'Jay',
  content: 'la page de connexion qui est sensée me rediriger sur une autre page (page utilisateur) ne fonctionne pas. Au départ'
},{
  id: '3',
  title: 'transferring xcode to visual studios(windows)',
  digest: 'work on visual studios (windows ) coding in c++',
  headingImg: 'https://avatars0.githubusercontent.com/u/34453386?v=4',
  publishedAt: '1\/1\/2018',
  publishedBy: 'Winnie',
  content: 'sometimes I can seem to find a way to transfer Xcode files to visual studios (windows files ), or from visual studios to Xcode. '
},{
  id: '4',
  title: 'How to build website like that',
  digest: 'help with website development',
  headingImg: 'https://avatars3.githubusercontent.com/u/34801805?v=4',
  publishedAt: '5\/1\/2017',
  publishedBy: 'Tu',
  content: 'www.sydney-webpages.com.au Any suggestions? This is the Wordpress template or any custom CMS?'
},{
  id: '5',
  title: 'Help with D1 mini and alexa',
  digest: 'projects for automated blinds which use Alexa',
  headingImg: 'https://avatars1.githubusercontent.com/u/35279313?v=4',
  publishedAt: '1\/2\/2017',
  publishedBy: 'Mai',
  content: 'Does anyone have the code for a wemos D1 mini to respond to these commands rather than “on” or “off” '
}]);

mock.onGet('/posts/1')
.reply(200, {
  id: '1',
  title: 'Login code problem',
  digest: 'android development',
  headingImg: 'https://avatars2.githubusercontent.com/u/34058688?v=4',
  publishedAt: '11\/12\/2017',
  publishedBy: 'Tom',
  content: 'Here, I encounter some difficulties including the login activity code'
});
mock.onGet('/posts/2')
.reply(200, {
  id: '2',
  title: 'Android Login/register app',
  digest: ' mini app semblable',
  headingImg: 'https://avatars2.githubusercontent.com/u/35514750?v=4',
  publishedAt: '1\/12\/2018',
  publishedBy: 'Jay',
  content: 'la page de connexion qui est sensée me rediriger sur une autre page (page utilisateur) ne fonctionne pas. Au départ'
});
mock.onGet('/posts/3')
.reply(200, {
  id: '3',
  title: 'transferring xcode to visual studios(windows)',
  digest: 'work on visual studios (windows ) coding in c++',
  headingImg: 'https://avatars0.githubusercontent.com/u/34453386?v=4',
  publishedAt: '1\/1\/2018',
  publishedBy: 'Winnie',
  content: 'sometimes I can seem to find a way to transfer Xcode files to visual studios (windows files ), or from visual studios to Xcode. '
});
mock.onGet('/posts/4')
.reply(200, {
  id: '4',
  title: 'How to build website like that',
  digest: 'help with website development',
  headingImg: 'https://avatars3.githubusercontent.com/u/34801805?v=4',
  publishedAt: '5\/1\/2017',
  publishedBy: 'Tu',
  content: 'www.sydney-webpages.com.au Any suggestions? This is the Wordpress template or any custom CMS?'
});
mock.onGet('/posts/5')
.reply(200, {
  id: '5',
  title: 'Help with D1 mini and alexa',
  digest: 'projects for automated blinds which use Alexa',
  headingImg: 'https://avatars1.githubusercontent.com/u/35279313?v=4',
  publishedAt: '1\/2\/2017',
  publishedBy: 'Mai',
  content: 'Does anyone have the code for a wemos D1 mini to respond to these commands rather than “on” or “off” '
});

export default class ListsView extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 
      isLoading: false,
      posts: [],
      store: null,
    };
  }

  componentDidMount() {
    this.loadPosts();
  }

  loadPosts() {
    this.setState({ isLoading: true });

    axios.get('/posts').then((response) => {
      this.setState({ posts: response.data, isLoading: false });
    });
  }

  render() {
    return (
      <div>
        <h1 className="title">Posts</h1>
        <Link to="/posts/create" className="btn btn-primary">Add new post</Link>
        {this.state.isLoading && <h3>Loading...</h3>}
        {!this.state.isLoading && (
          <div className="row">
            {this.state.posts.map(post => <PostCard key={post.id} post={post} />)}
          </div>
        )}
      </div>
    );
  }
}