#Test Project's README

## How to install and run

Run the following commands

```
npm install
npm run dev

```

You only need to run `npm install` at the first time.